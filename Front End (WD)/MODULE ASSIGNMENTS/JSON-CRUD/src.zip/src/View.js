import React, { useEffect, useState } from 'react'
import {useParams } from 'react-router-dom'

function View() {    
  const [stddata,setstdData] = useState('')
  const  { id }  = useParams () 

 
     useEffect(() => {
            fetch(`http://localhost:500/students/${id}`)
                .then((res) => { return res.json() })
                .then((data) => {
                    setstdData(data)   
                })

        }, [])
  return (
    <div>
      <>
        <div className='container'>
          <div className='row justify-content-left '>
            <div className='col'>
              <h3>View Students Details</h3>
              <div>
                <h3>{stddata.name}</h3>
                <h3>{stddata.email}</h3>
              </div>
            </div>
          </div>
        </div>
      </>

    </div>
  )
}

export default View