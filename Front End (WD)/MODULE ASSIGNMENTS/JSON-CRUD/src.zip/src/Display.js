import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';

function Display() {
    const [data, setData] = useState([]);

    useEffect(() => {
        fetch('http://localhost:500/students')
            .then((res) => { return res.json() })
            .then((data) => {
                setData(data)
            })
    })
    const handelDelete = (id) => {

        fetch('http://localhost:500/students/' + id, {
            method: "delete",
            headers: { "content-type": "application/json" },
        })

    }
    return (
        <div>
            <div className='container'>
                <div className='row justify-content-center'>
                    <div className='col-xl-6'>
                        <div>
                            <h3>Students Details</h3>
                            <Link to='/add' className='btn btn-warning my-3'>Add Students</Link>
                        </div>
                        <div>
                            <table className='table'>
                                <thead className='table-dark'>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {data.map((std) => (
                                        <tr key={std.id}>
                                            <td>{std.id}</td>
                                            <td>{std.name}</td>
                                            <td>{std.email}</td>
                                            <td>
                                                <Link to={`/view/${std.id}`} className='btn btn-info'>View</Link>
                                                <Link to={`/edit/${std.id}`} className='btn btn-success mx-2'>Edit</Link>
                                                <button onClick={() => { handelDelete(std.id) }} className='btn btn-danger' >Delete</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default Display
