import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function AddStudents() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("")
    const navigate = useNavigate();
    const test = () => {
        // alert(1)
        navigate('/')

    }

    function handleAdd(e) {
        //    console.log(e)
        e.preventDefault();
        // console.log({name,email})
        let obj = { name, email };
        fetch('http://localhost:500/students', {
            method: 'post',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(obj)
        })
            .then((res) => {
                if (res) {
                   
                    navigate('/')
                }
            })
        // .then(
        //     (data)=>{console.log(data)}
        // )
    }
    return (
        <div>
            <div className='container'>
                <div className='row justify-content-center text-start'>
                    <div className='col-xl-6'>
                        <div>
                            <h3>Add Students Details</h3>
                            <button onClick={test} className='btn btn-warning my-3'>Go back</button>
                        </div>
                        <div>
                            <form onSubmit={handleAdd}>
                                <div>
                                    <label>Name :</label>
                                    <input type="text" name="" value={name} onChange={(e) => { setName(e.target.value) }} className='form-control' />
                                </div>
                                <div>
                                    <label>Email :</label>
                                    <input type="text" name="" value={email} onChange={(e) => { setEmail(e.target.value) }} className='form-control' />
                                </div>
                                <div>
                                    <input type="submit" value="Add" className='btn btn-primary my-3' />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AddStudents
