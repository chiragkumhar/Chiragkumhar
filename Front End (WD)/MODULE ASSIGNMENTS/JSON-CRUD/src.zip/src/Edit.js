import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'

function Edit() {
    const { id } = useParams()
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const handledit = () => {

        fetch('http://localhost:500/students/' + id, {
            method: 'put',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ name, email })
        })
    }
    return (
        <div>
            <h1>Edit Data</h1>
            <div className='container'>
                <div className='row justify-content-center text-start'>
                    <div className='col-xl-6'>
                        <div>
                            <h3>Add Students Details</h3>
                            <Link to={"/"} className='btn btn-warning my-3'>Home</Link>
                        </div>
                        <div>
                            <form>
                                <div>
                                    <label>Name :</label>
                                    <input type="text" value={name} onChange={(e) => { setName(e.target.value) }} className='form-control' />
                                </div>
                                <div>
                                    <label>Email :</label>
                                    <input type="text" value={email} onChange={(e) => { setEmail(e.target.value) }} className='form-control' />
                                </div>
                                <div>
                                    <input onClick={handledit} type="button" value="Update" className='btn btn-primary my-3' />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Edit
