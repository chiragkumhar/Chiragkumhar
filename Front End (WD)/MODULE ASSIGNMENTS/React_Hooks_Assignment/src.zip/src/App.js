import logo from './logo.svg';
import './App.css';
import UseStateHook from './UseStateHook';
import UseEffectHook from './UseEffectHook';
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import UseMemoHook from './UseMemoHook';

function App() {
  return (
    <div className="App">
      <UseStateHook></UseStateHook>
      <UseEffectHook></UseEffectHook>
      <UseMemoHook></UseMemoHook>
    </div>
  );
}

export default App;
