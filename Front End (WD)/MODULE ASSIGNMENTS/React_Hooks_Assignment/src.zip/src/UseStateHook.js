import React, { useState } from 'react'

function UseStateHook() {
    const [state, setState] = useState(1)
    return (
        <div className='container bg-success p-3'>
            <h1>UseStateHook</h1>
            <button className='btn btn-primary' onClick={() => { setState(state + 1) }}>+</button>
            <h1>{state}</h1>
            <button className='btn btn-danger' onClick={() => { setState(state - 1) }}>-</button>
        </div>
    )
}

export default UseStateHook
