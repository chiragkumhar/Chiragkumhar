import React, { useState, useMemo } from "react";

const UseMemoHook = () => {
    const [count, setCount] = useState(0);
    const abc = useMemo(() => count, [count]);

    return (
        <div>
            <button onClick={() => setCount(count + 1)}>+</button>
            <h2>{abc}</h2>
            <button onClick={() => setCount(count - 1)}>-</button>
        </div>
    );
};

export default UseMemoHook;
