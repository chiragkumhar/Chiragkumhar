import React, { useEffect, useState } from 'react'

function UseEffectHook() {
    const [data, setData] = useState([])
    useEffect(() => {
        fetch('https://jsonplaceholder.typicode.com/users')
            .then((res) => { return res.json() })
            .then((data) => {
                // console.log(data)
                setData(data)
            })
    }, [])
    return (
        <div>
            <h1>UseEffect Hook</h1>
            <table className='table'>
                <thead  className='table-dark'>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((users) => {
                        return (
                            <tr key={users.id}>
                                <td>{users.id}</td>
                                <td>{users.name}</td>
                            </tr>
                        )
                    })}
                </tbody>
            </table>
        </div>)
}


export default UseEffectHook
