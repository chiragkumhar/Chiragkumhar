import logo from './logo.svg';
import './App.css';
import Assessment from './Assessment';
import Accordion from './Accordion';
function App() {
  return (
    <div className="App">
      <h1>Assessment </h1>
      <Assessment></Assessment>
      <Accordion></Accordion>
    </div>
  );
}

export default App;
