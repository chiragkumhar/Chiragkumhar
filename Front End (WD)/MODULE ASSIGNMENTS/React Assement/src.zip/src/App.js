import logo from './logo.svg';
import './App.css';
import Assessment from './Assessment';
function App() {
  return (
    <div className="App">
      <h1>Assessment </h1>
  <Assessment></Assessment>
    </div>
  );
}

export default App;
