import React, { useState } from "react";

const accordionItems = [
    { title: "What is your return policy?", content: "We offer a 30-day return policy from the date of delivery. Items must be unused, in their original packaging, and accompanied by a receipt or proof of purchase. Some items, such as personalized or final-sale products, may not be eligible for return. To initiate a return, please visit our Returns & Exchanges page or contact our customer support team." },
    { title: "How do I track my order?", content: "Once your order is shipped, you will receive a tracking number via email or SMS. You can use this tracking number to check the real-time status of your shipment on our Order Tracking page. If you have an account with us, you can also log in to view your order history and tracking details." },
    { title: "Can I purchase items again?", content: "Yes! If you’d like to reorder a product, simply visit the Order History section in your account and select Reorder. You can also search for the product on our website and add it to your cart for a new purchase.." },
];

function Accordion() {
    const [selectedIndex, setSelectedIndex] = useState(null);

    return (
        <div>
            {accordionItems.map((value, index) => (
                <div className="border w-50 text-start m-auto p-3" key={value.title}>
                    <div>
                        <span className="span" onClick={() => { setSelectedIndex(index) }}>{value.title} <i className="fa-solid fa-angle-down"></i></span>
                        <br />
                        <p style={{ display: selectedIndex == index ? "block" : "none" }}>
                            {value.content}
                        </p>
                    </div>
                </div>
            ))}
        </div>
    );
}

export default Accordion;
