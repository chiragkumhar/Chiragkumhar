import React, { createContext, useContext, useState } from "react";

const ChecklistContext = createContext();

const Assesement = () => {
  const [isCitizen, setIsCitizen] = useState(null);
  const [isOver21, setIsOver21] = useState(false);

  let toggleCitizen = (e) => setIsCitizen(e.target.checked)
  let toggleOver21 = (e) => setIsOver21(e.target.checked);
  console.log(isCitizen);

  return (
    <ChecklistContext.Provider value={{ isCitizen, toggleCitizen, isOver21, toggleOver21 }}>
      <Checklist></Checklist>
    </ChecklistContext.Provider>
  );
};

const Checklist = () => {
  let { isCitizen, toggleCitizen, isOver21, toggleOver21 } = useContext(ChecklistContext);

  return (
    <div>
      <label>
        <input type="checkbox" checked={isCitizen} onChange={toggleCitizen} />
        Are you a Citizen?
      </label>
      <br />
      <label>
        <input type="checkbox" checked={isOver21} onChange={toggleOver21} />
        Are you over 21?
      </label>
      <h3>Are you a Citizen: {isCitizen ? "Yes" : "No"}</h3>
      <h3>Are you over 21: {isOver21 ? "Yes" : "No"}</h3>
    </div>
  );
};


export default Assesement

