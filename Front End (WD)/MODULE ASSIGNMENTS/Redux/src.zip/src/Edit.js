import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useParams } from 'react-router-dom'
import { editdata } from './reducer'

function Edit() {
  const [name, setName] = useState("")
  const [price, setPrice] = useState("")
  const [product] = useSelector(state => state.prddata)
  const { id } = useParams()
  const dispatch = useDispatch()

  // console.log(name, price)
  useEffect(() => {
    fetch('http://localhost:500/product/' + id)
      .then((res) => { return res.json() })
      .then((data) => {
        setName(data.name)
        setPrice(data.price)
      })
  }, []);

  const handleedit = (e) => {
    e.preventDefault()
    dispatch(editdata({ id: id, name, price }))
    window.location.reload()
  }


  return (
    <div>
      <div className='container'>
        <h1>Edit Products</h1>
        <Link to={'/'} className="btn btn-success" >Home</Link>

        <form className='text-start' onSubmit={handleedit}>
          <div className="mb-3">
            <label className="form-label">Name : </label>
            <input value={name} onChange={(e) => { setName(e.target.value) }} type="text" className="form-control" />
          </div>

          <div className="mb-3">
            <label className="form-label">Price : </label>
            <input type="text" value={price} onChange={(e) => { setPrice(e.target.value) }} className="form-control" />
          </div>

          <button type="submit" className="btn btn-primary">Submit</button>
        </form>

      </div>
    </div>
  )
}

export default Edit
