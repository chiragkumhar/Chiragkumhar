import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import Display from './Display';
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import Add from './Add';
import Edit from './Edit';

function App() {
  return (
    <div className="App">
      <h1>Redux Json CRUD</h1>
      <BrowserRouter>
        <Link to='/'></Link>
        <Routes>
          <Route path='/' element={<Display />}></Route>
          <Route path='/add' element={<Add></Add>}></Route>
          <Route path='/edit/:id' element={<Edit/>}></Route>
        </Routes></BrowserRouter>
    </div>
  );
}

export default App;
