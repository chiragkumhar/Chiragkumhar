import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { Link } from 'react-router-dom'
import { putData } from './reducer'

function Add() {
  const [name, setName] = useState("")
  const [price, setPrice] = useState("")

  const dispatch = useDispatch()
  const handleadd = (e) => {
    e.preventDefault()

    dispatch(putData({ name, price }))
    window.location.reload()
  }
  return (
    <div className='container'>
      <h1>Add New Products</h1>
      <Link to={'/'} className="btn btn-success" >Home</Link>

      <form className='text-start' onSubmit={handleadd}>
        <div className="mb-3">
          <label className="form-label">Name : </label>
          <input value={name} onChange={(e) => { setName(e.target.value) }} type="text" className="form-control" />
        </div>

        <div className="mb-3">
          <label className="form-label">Price : </label>
          <input value={price} onChange={(e) => { setPrice(e.target.value) }} type="text" className="form-control" />
        </div>

        <button type="submit" className="btn btn-primary">Submit</button>
      </form>

    </div>
  )
}

export default Add
