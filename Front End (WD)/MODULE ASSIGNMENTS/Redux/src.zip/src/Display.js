import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { adddata, deldata } from './reducer';
import { Link } from 'react-router-dom';

function Display() {
  const [product] = useSelector(state => state.prddata)
  const dispatch = useDispatch()

  // console.log(product)
  useEffect(() => {
    fetch('http://localhost:500/product')
      .then((res) => res.json())
      .then((data) => {
        dispatch(adddata(data))

      })
  }, []);
  const handleDelete = (id) => {
    dispatch(deldata({ id }))

    window.location.reload()
  }


  return (
    <div className='container'>
      <h2>Products Details</h2>

      <Link to={'/add'} className='btn btn-warning my-4'>Add Data</Link>

      <table className='table'>

        <thead className='table-dark'>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Price</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {product && product.map((prd) => {
            return (
              <tr key={prd.id}>
                <td>{prd.id}</td>
                <td>{prd.name}</td>
                <td>{prd.price}</td>
                <td>
                  <Link className='btn btn-success me-2' to={'/edit/' + prd.id}>Edit</Link>
                  <button className='btn btn-danger' onClick={() => { handleDelete(prd.id) }} >Delete</button>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>

    </div>
  )
}

export default Display