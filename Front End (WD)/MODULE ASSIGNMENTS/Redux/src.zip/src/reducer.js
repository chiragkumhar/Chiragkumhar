import { createSlice } from "@reduxjs/toolkit";
import { act } from "react";

const productslice = createSlice({
    name: "product",
    initialState: [],
    reducers: {
        adddata: (state, action) => {
            // console.log(state, action)

            state.push(action.payload)
        },

        putData: (state, action) => {
            console.log(state)
            console.log(action.payload)


            fetch('http://localhost:500/product', {
                method: "post",
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify(action.payload)
            })

            state.push(action.payload)
        },
        editdata: (state, action) => {
            // console.log(state)
            // console.log(action.payload)    
            const { id, name, price } = action.payload
            console.log(JSON.stringify({ name, price }))


            fetch('http://localhost:500/product/' + id, {
                method: "put",
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify({ name, price })
            })

            state.push(action.payload)
        },
        deldata: (state, action) => {
            console.log(state)
            console.log(action.payload)

            const { id } = action.payload

            fetch('http://localhost:500/product/' + id, {
                method: "delete",
                headers: { 'content-type': 'application/json' },

            })


            state.push(action.payload)

        }

    }
})
export default productslice.reducer
export const { adddata, putData, editdata, deldata } = productslice.actions